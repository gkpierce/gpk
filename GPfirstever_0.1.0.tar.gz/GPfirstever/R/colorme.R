#'Color me colorful
#'
#'
#'@export

all_in_the_name <- function(n) {
  colors <- c("peachpuff1", "lightgoldenrodyellow", "lemonchiffon3", "bisque", "olivedrab")
  return(rep(colors, length.out = n))
}
