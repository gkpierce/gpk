#' GP's first ever!
#'
#' @param x numeric type vector
#'
#' @return given numeric vector compute the log of the sum of the exponentials
#' of elements of x


#' @export
log_sum <- function(n, x) {
  s <- 0
  for (i in 1:n) {
    s <- s + exp(x[i])
  }
  return(log(s))
}

n <- 2000
x <- 1:n

log_sum(n, x)
