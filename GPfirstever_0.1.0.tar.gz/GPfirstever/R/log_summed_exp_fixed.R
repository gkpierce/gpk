#' GP's first ever!
#'
#' @param x numeric type vector
#'
#' @return given numeric vector compute the log of the sum of the exponentials
#' of elements of x (this time without limitations)
#'
#' @export

log_summed_exp_fix<- function(n, x) {
  maxx <- max(x)
  q <- 0
  r <- 1
  for (i in 1:n) {
    r <- r * (1 + exp(x[i] - maxx) / r)
    q <- q + log(1 + exp(x[i] - maxx))
  }
  return(maxx + log(r) + q)
}

n <- 2000
x <- 1:n

log_summed_exp_fix(n, x)
