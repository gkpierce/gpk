#' Amy's CLR (not mine)
#'
#' @param x numeric type vector
#'
#' @return Centered log ratio transform of vector input

#' @export
g <- function(x){
  log(x)-mean(log(x))
}
x<- 2
g(x)
